// ******************* ReactJS - HOL 1 ***********************************
import ReactDOM from 'react-dom/client'
import React from 'react'
//point1
const root = ReactDOM.createRoot(document.getElementById("root"))
root.render(<h1>Hello Clans!</h1>)

//point2.a
const p1= ReactDOM.createRoot(document.getElementById("p1")).render(<h1>This is Blazeclan!</h1>)

//point2.b
const p= ReactDOM.createRoot(document.querySelector("#p")).render(<h1>Hi, My Name is Indranil Champati !</h1>)

// ===============================================================================================================
//point 3

// import  ReactDOM  from 'react-dom/client'

const navbar =(
  <nav>
    <h1>React features</h1>
    <ul>
      <li>JSX</li>
      <li>Components</li>
      <li>Virtual DOM</li>
      <li>Simplicity</li>
      <li>Performance</li>
    </ul>
  </nav>
)
// ReactDOM.render(navbar,document.getElementById("nv"))
ReactDOM.createRoot(document.getElementById("nv")).render(navbar)
console.log("Data is displayed");
// ===============================================================================================================
// const theList=<div><h3>React Features</h3><ul>
//     <li>JSX</li>
//     <li>Components</li>
//     <li>Virtual Dom</li>
//     <li>Simplicity</li>
//     <li>Performance</li>
//     </ul></div>
// ReactDOM.createRoot(document.getElementById("list")).render(theList)
// console.log("Data is displayed");