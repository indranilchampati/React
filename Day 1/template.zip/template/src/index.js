//Q9
// const root = ReactDOM.createRoot(document.getElementById("root")).render(<h1>Hello,Once Again....
//     Welcome To Blazeclan!!</h1>)

//Q10
const main = (
    <div>
        <h1>Welcome to React</h1>
        <ol>
            <li>React is Composable</li>
            <li>React is Declarative</li>
        </ol>
    </div>
)
// document.getElementById("root").append(main)
document.getElementById("root").append(JSON.stringify(main))